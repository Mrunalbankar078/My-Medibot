function togglePopup(id) {
    const popup = document.getElementById(id);
    popup.style.display = (popup.style.display === "block" ? "none" : "block");
}
let symptomsData = [];

// Load JSON data when page loads
window.onload = async () => {
  await loadSymptomsJSON();
  setupAutocomplete();
};

async function loadSymptomsJSON() {
  try {
    const res = await fetch("data/symptoms.json");// Adjust path if needed
    symptomsData = await res.json();
  } catch (error) {
    console.error("Error loading symptoms.json:", error);
  }
}

function checkSymptomOffline() {
  const input = document.getElementById("symptom").value.toLowerCase();
  const responseDiv = document.getElementById("response");
  let found = false;

  for (const symptom of symptomsData) {
    if (symptom.keywords.some(k => input.includes(k))) {
      responseDiv.innerHTML = `
        <strong>${symptom.name}</strong> detected.<br>
        <b>Category:</b> ${symptom.category}<br>
        <b>Medicines:</b> ${symptom.medicines.join(", ")}<br>
        <b>Advice:</b> ${symptom.advice}
      `;
      found = true;
      break;
    }
  }

  if (!found) {
    responseDiv.innerHTML = "Symptom not recognized. Please consult a doctor.";
  }
}

function setupAutocomplete() {
  const input = document.getElementById("symptom");
  const datalist = document.getElementById("symptom-list");
  const seen = new Set();

  symptomsData.forEach(symptom => {
    symptom.keywords.forEach(keyword => {
      if (!seen.has(keyword)) {
        const option = document.createElement("option");
        option.value = keyword;
        datalist.appendChild(option);
        seen.add(keyword);
      }
    });
  });
}

// Offline Symptom Checker
function checkSymptomOffline() {
    const symptom = document.getElementById("symptom").value.toLowerCase();
    let result = "";

    if (symptom.includes("fever")) {
        result = `Fever detected.<br>Medicines: Paracetamol, Ibuprofen.<br>Advice: Rest, hydration.`;
    } else if (symptom.includes("cold")) {
        result = `Common cold detected.<br>Medicines: Cetzine, Levocet.<br>Syrups: Honitus, Ascoril D.`;
    } else if (symptom.includes("headache")) {
        result = `Headache detected.<br>Medicines: Crocin, Ibuprofen.<br>Advice: Sleep, reduce screen time.`;
    } else if (symptom.includes("cough")) {
        result = `Cough detected.<br>Syrups: Benadryl, Grilinctus.<br>Advice: Warm water, honey.`;
    } else if (symptom.includes("diabetes")) {
        result = `Symptoms of Diabetes.<br>Medicines: Metformin, Insulin.<br>Advice: Diet control, doctor consultation.`;
    } else {
        result = `Symptom not recognized. Please consult a doctor.`;
    }




    if (symptom.includes("fever")) {
        result = `Fever detected.<br>Medicines: Paracetamol, Ibuprofen.<br>Advice: Rest, hydration.`;
    } else if (symptom.includes("cold")) {
        result = `Common cold detected.<br>Medicines: Cetzine, Levocet.<br>Syrups: Honitus, Ascoril D.`;
    } else if (symptom.includes("headache")) {
        result = `Headache detected.<br>Medicines: Crocin, Ibuprofen.<br>Advice: Sleep, reduce screen time.`;
    } else if (symptom.includes("cough")) {
        result = `Cough detected.<br>Syrups: Benadryl, Grilinctus.<br>Advice: Warm water, honey.`;
    } else if (symptom.includes("diabetes")) {
        result = `Symptoms of Diabetes.<br>Medicines: Metformin, Insulin.<br>Advice: Diet control, doctor consultation.`;
    } else if (symptom.includes("asthma")) {
        result = `Asthma detected.<br>Medicines: Salbutamol, Budesonide.<br>Advice: Avoid allergens, use inhalers regularly.`;
    } else if (symptom.includes("allergy")) {
        result = `Allergic reaction detected.<br>Medicines: Cetirizine, Loratadine.<br>Advice: Identify triggers, consult allergist.`;
    } else if (symptom.includes("vomiting")) {
        result = `Vomiting detected.<br>Medicines: Ondansetron, Domperidone.<br>Advice: Stay hydrated, eat light.`;
    } else if (symptom.includes("diarrhea")) {
        result = `Diarrhea detected.<br>Medicines: ORS, Loperamide.<br>Advice: Hydration is key, avoid solid food.`;
    } else if (symptom.includes("constipation")) {
        result = `Constipation detected.<br>Medicines: Lactulose, Isabgol.<br>Advice: Fiber-rich diet, drink water.`;
    } else if (symptom.includes("sore throat")) {
        result = `Sore throat detected.<br>Medicines: Lozenges, Paracetamol.<br>Advice: Warm salt water gargle, rest voice.`;
    } else if (symptom.includes("flu")) {
        result = `Flu-like symptoms detected.<br>Medicines: Antiviral drugs, Paracetamol.<br>Advice: Rest and monitor fever.`;
    } else if (symptom.includes("acidity")) {
        result = `Acidity detected.<br>Medicines: Rantac, Pantoprazole.<br>Advice: Avoid spicy food, eat on time.`;
    } else if (symptom.includes("gas")) {
        result = `Gas problem detected.<br>Medicines: Simethicone, Digene.<br>Advice: Avoid carbonated drinks.`;
    } else if (symptom.includes("hypertension")) {
        result = `High blood pressure detected.<br>Medicines: Amlodipine, Losartan.<br>Advice: Low-salt diet, regular BP check.`;
    } else if (symptom.includes("heart pain") || symptom.includes("chest pain")) {
        result = `Possible heart-related issue.<br>Medicines: Sorbitrate (only if prescribed).<br>Advice: Immediate doctor consultation.`;
    } else if (symptom.includes("acne")) {
        result = `Acne detected.<br>Medicines: Benzoyl Peroxide, Clindamycin Gel.<br>Advice: Wash face regularly, avoid oily foods.`;
    } else if (symptom.includes("eczema")) {
        result = `Eczema symptoms detected.<br>Medicines: Hydrocortisone cream, Moisturizers.<br>Advice: Avoid irritants, keep skin hydrated.`;
    } else if (symptom.includes("dandruff")) {
        result = `Dandruff detected.<br>Medicines: Ketoconazole shampoo.<br>Advice: Regular hair wash, avoid harsh products.`;
    } else if (symptom.includes("eye pain")) {
        result = `Eye pain detected.<br>Medicines: Lubricating drops, Antibiotic drops.<br>Advice: Limit screen time, consult ophthalmologist.`;
    } else if (symptom.includes("ear pain")) {
        result = `Ear pain detected.<br>Medicines: Ciplox drops, Paracetamol.<br>Advice: Avoid inserting objects, consult ENT.`;
    } else if (symptom.includes("toothache")) {
        result = `Toothache detected.<br>Medicines: Ibuprofen, Clove oil.<br>Advice: Visit dentist, avoid cold drinks.`;
    } else if (symptom.includes("back pain")) {
        result = `Back pain detected.<br>Medicines: Muscle relaxants, Ibuprofen.<br>Advice: Avoid heavy lifting, use lumbar support.`;
    } else if (symptom.includes("joint pain")) {
        result = `Joint pain detected.<br>Medicines: Diclofenac, Glucosamine.<br>Advice: Physiotherapy, hot/cold compress.`;
    } else if (symptom.includes("burn")) {
        result = `Burn detected.<br>Medicines: Silverex cream.<br>Advice: Cold water rinse, avoid breaking blisters.`;
    } else if (symptom.includes("wound")) {
        result = `Wound care needed.<br>Medicines: Antiseptic cream, Betadine.<br>Advice: Keep it clean and covered.`;
    } else if (symptom.includes("fracture")) {
        result = `Possible fracture.<br>Advice: Immobilize, visit hospital immediately.`;
    } else if (symptom.includes("sprain")) {
        result = `Sprain detected.<br>Medicines: Pain relievers.<br>Advice: R.I.C.E. (Rest, Ice, Compress, Elevate).`;
    } else if (symptom.includes("period pain")) {
        result = `Menstrual cramps detected.<br>Medicines: Meftal Spas.<br>Advice: Hot water bag, light exercise.`;
    } else if (symptom.includes("pregnancy")) {
        result = `Pregnancy symptoms detected.<br>Advice: Take folic acid, consult gynecologist.`;
    } else if (symptom.includes("urine pain")) {
        result = `Possible UTI.<br>Medicines: Antibiotics (prescribed only).<br>Advice: Drink plenty of water.`;
    } else if (symptom.includes("hair fall")) {
        result = `Hair fall detected.<br>Medicines: Minoxidil, Biotin.<br>Advice: Avoid stress, good diet.`;
    } else if (symptom.includes("anemia")) {
        result = `Anemia symptoms detected.<br>Medicines: Iron supplements.<br>Advice: Iron-rich foods, regular blood tests.`;
    } else if (symptom.includes("thyroid")) {
        result = `Thyroid imbalance suspected.<br>Medicines: Thyronorm.<br>Advice: Blood test, regular dosage.`;
    } else if (symptom.includes("sleep")) {
        result = `Insomnia symptoms detected.<br>Medicines: Melatonin (consult doctor).<br>Advice: Reduce caffeine, fixed sleep time.`;
    } else if (symptom.includes("anxiety")) {
        result = `Anxiety symptoms detected.<br>Medicines: As prescribed.<br>Advice: Relaxation, talk therapy.`;
    } else if (symptom.includes("depression")) {
        result = `Depression symptoms detected.<br>Medicines: Antidepressants (consult psychiatrist).<br>Advice: Talk to someone, exercise.`;
    } else {
        result = `Symptom not recognized. Please consult a doctor.`;
    }
    

    
    
    
    
    
    
    
    
    
    
    
    
    document.getElementById("response").innerHTML = result;
}

// Online Symptom Checker (Gemini AI)
async function checkSymptomOnline() {
    const symptomInput = document.getElementById("symptom");
    const symptom = symptomInput.value.trim();

    const responseDiv = document.getElementById("response");

    if (!symptom) {
        responseDiv.innerText = "Please enter a symptom.";
        return;
    }

    // Show loading message every time
    responseDiv.innerText = "Checking with AI...";

    try {
        const res = await fetch("http://localhost:5500/api/ask", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                prompt: `I have the following symptoms: ${symptom}. What could it be?`
            })
        });

        const data = await res.json();
        responseDiv.innerText = data.reply || "No response received.";
    } catch (err) {
        console.error(err);
        responseDiv.innerText = "Error contacting Medibot AI.";
    }
}


// Chat or Medicine AI Suggestion
async function handleUserQuery() {
    const chatInput = document.getElementById("chatInput")?.value;
    const medicineInput = document.getElementById("medicineInput")?.value;
    const input = chatInput || medicineInput;
    const isChat = !!chatInput;
    const outputDiv = document.getElementById(isChat ? "chatResponse" : "medicineResponse");

    outputDiv.innerText = "Contacting Medibot AI...";

    try {
        const res = await fetch("http://localhost:5500/api/ask", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt: input })
        });

        const data = await res.json();
        outputDiv.innerText = data.reply || "No response received.";
    } catch (err) {
        console.error(err);
        outputDiv.innerText = "AI service error.";
    }
}

function findHospitals() {
    const hospitalDiv = document.getElementById('hospitalResults');
    hospitalDiv.innerHTML = "Locating nearby hospitals and clinics...";

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;

            const query = encodeURIComponent("hospitals and clinics");
            const mapUrl = `https://www.google.com/maps/search/${query}/@${lat},${lon},15z`;

            hospitalDiv.innerHTML = `
                <p>Click below to view hospitals and clinics near you:</p>
                <a href="${mapUrl}" target="_blank">Open Google Maps</a>
            `;
        }, () => {
            hospitalDiv.innerText = "Unable to access your location.";
        });
    } else {
        hospitalDiv.innerText = "Geolocation not supported by your browser.";
    }
}
function startVoiceInput() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.start();
  
    recognition.onresult = (event) => {
      const speechResult = event.results[0][0].transcript;
      document.getElementById('symptom').value = speechResult.toLowerCase();
    };
  
    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      alert('Could not recognize voice. Try again.');
    };
  }
  
  function callEmergency() {
    window.location.href = "tel:112";
  }
  
  function alertEmergencyContact() {
    alert("Emergency contact has been notified! (Simulated)");
    // Later, use SMS API / Email service
  }
  
  let reminders = JSON.parse(localStorage.getItem("reminders")) || [];

function addReminder() {
  const name = document.getElementById("pillName").value;
  const time = document.getElementById("pillTime").value;
  if (!name || !time) return alert("Fill both fields");

  reminders.push({ name, time, taken: false });
  localStorage.setItem("reminders", JSON.stringify(reminders));
  displayReminders();
}

function displayReminders() {
  const list = document.getElementById("reminderList");
  list.innerHTML = "";
  reminders.forEach((reminder, index) => {
    const li = document.createElement("li");
    li.innerHTML = `${reminder.name} at ${reminder.time}
      <button onclick="markTaken(${index})">${reminder.taken ? '✅' : 'Mark as taken'}</button>`;
    list.appendChild(li);
  });
}

function markTaken(index) {
  reminders[index].taken = true;
  localStorage.setItem("reminders", JSON.stringify(reminders));
  displayReminders();
}

// Run on load
window.onload = () => {
  setupAutocomplete();  // your existing function
  displayReminders();   // pill reminders
};
 
function addReminder() {
    const name = document.getElementById("pillName").value;
    const time = document.getElementById("pillTime").value;
  
    if (!name || !time) {
      alert("Please enter both medicine name and time.");
      return;
    }
  
    const reminder = { name, time };
    const reminders = JSON.parse(localStorage.getItem("pillReminders") || "[]");
    reminders.push(reminder);
    localStorage.setItem("pillReminders", JSON.stringify(reminders));
  
    displayReminders();
    document.getElementById("pillName").value = "";
    document.getElementById("pillTime").value = "";
  }
  
  function displayReminders() {
    const list = document.getElementById("reminderList");
    list.innerHTML = "";
    const reminders = JSON.parse(localStorage.getItem("pillReminders") || "[]");
  
    reminders.forEach((r, index) => {
      const li = document.createElement("li");
      li.textContent = `💊 ${r.name} at ${r.time}`;
      const delBtn = document.createElement("button");
      delBtn.textContent = "❌";
      delBtn.onclick = () => deleteReminder(index);
      li.appendChild(delBtn);
      list.appendChild(li);
    });
  }
  
  function deleteReminder(index) {
    const reminders = JSON.parse(localStorage.getItem("pillReminders") || "[]");
    reminders.splice(index, 1);
    localStorage.setItem("pillReminders", JSON.stringify(reminders));
    displayReminders();
  }
  
  // Call on page load
  window.onload = function () {
    setupAutocomplete(); // your symptom autocomplete
    displayReminders();
  };
  