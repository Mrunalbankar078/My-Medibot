const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Replace with your actual Gemini API key
const GEMINI_API_KEY = 'AIzaSyBZNAmrdvrXmR629mQIGGN2000IDCLkUzo';

// === Main endpoint for frontend ===
app.post('/api/ask', async (req, res) => {
    const userPrompt = req.body.prompt;

    try {
        const response = await axios.post(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
            {
                contents: [
                    {
                        parts: [
                            { text: userPrompt }
                        ]
                    }
                ]
            },
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );

        const reply = response.data.candidates?.[0]?.content?.parts?.[0]?.text || "No reply received.";
        res.json({ reply });

    } catch (error) {
        console.error("Error from Gemini API:", error.message);
        res.status(500).json({ error: "Failed to contact Gemini API." });
    }
});

// Start server
app.listen(5500, () => {
    console.log("Server is running on http://localhost:5500");
});
